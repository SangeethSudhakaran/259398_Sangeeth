﻿namespace ListManagement
{
    partial class frmListView
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listViewData = new ListView();
            Id = new ColumnHeader();
            Code = new ColumnHeader();
            ItemName = new ColumnHeader();
            label1 = new Label();
            btnAdd = new Button();
            btnRemove = new Button();
            SuspendLayout();
            // 
            // listViewData
            // 
            listViewData.Columns.AddRange(new ColumnHeader[] { Id, Code, ItemName });
            listViewData.FullRowSelect = true;
            listViewData.GridLines = true;
            listViewData.Location = new Point(12, 39);
            listViewData.Name = "listViewData";
            listViewData.Size = new Size(776, 340);
            listViewData.TabIndex = 0;
            listViewData.UseCompatibleStateImageBehavior = false;
            listViewData.View = View.Details;
            // 
            // Id
            // 
            Id.Text = "Id";
            Id.Width = 0;
            // 
            // Code
            // 
            Code.Text = "Item Code";
            Code.Width = 100;
            // 
            // ItemName
            // 
            ItemName.Text = "Item Name";
            ItemName.Width = 400;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 4);
            label1.Name = "label1";
            label1.Size = new Size(304, 28);
            label1.TabIndex = 1;
            label1.Text = "Mange data using the ListView";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(11, 394);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(111, 394);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(94, 29);
            btnRemove.TabIndex = 3;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // frmListView
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(796, 435);
            Controls.Add(btnRemove);
            Controls.Add(btnAdd);
            Controls.Add(label1);
            Controls.Add(listViewData);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "frmListView";
            Text = "Manage List data";
            Load += frmListView_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView listViewData;
        private ColumnHeader Id;
        private ColumnHeader Code;
        private ColumnHeader ItemName;
        private Label label1;
        private Button btnAdd;
        private Button btnRemove;
    }
}