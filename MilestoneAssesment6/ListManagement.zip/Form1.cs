using Microsoft.VisualBasic;

namespace ListManagement
{
    public partial class frmListView : Form
    {
        int itemId = 0;
        public frmListView()
        {
            InitializeComponent();
        }

        //Add item by taking user input
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string itemCode = Interaction.InputBox("Please enter item code", "User input");
            string itemName = Interaction.InputBox("Please enter item name", "User input");
            if (!string.IsNullOrEmpty(itemCode) && !string.IsNullOrEmpty(itemName))
            {
                AddNewItem(itemCode, itemName);
            }
            else
            {
                MessageBox.Show("Please input the item details!");
            }
        }

        //Remove selected items
        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Check item selected or not
            if (listViewData.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listViewData.SelectedItems)
                {
                    listViewData.Items.Remove(item);
                }
            }
            else
            {
                MessageBox.Show("Please select an item to remove");
            }
        }

        //Add initial data
        private void frmListView_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 7; i++)
            {
                AddNewItem("100" + i, "Sample item " + i);
            }
        }

        //Common method to add new item
        private void AddNewItem(string itemCode, string itemName)
        {
            itemId += 1;
            ListViewItem item = new ListViewItem(itemId.ToString());
            item.SubItems.Add(itemCode);
            item.SubItems.Add(itemName);
            listViewData.Items.Add(item);
        }
    }
}