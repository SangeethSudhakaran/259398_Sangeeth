﻿namespace GeneratePDFFromCSV
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //CSV data file directory
            string csvFilePath = "Data.csv";

            //Directory to save the output pdf file
            string pdfFilePath = "SummaryReportFromCSV.pdf";

            //Read data from CSV and add into the person List
            List<Person> people = ManageCSV.ReadCsvFile(csvFilePath);

            //Generate PDF report from person list
            ManageCSV.GeneratePdfReport(people, pdfFilePath);
        }
    }
}