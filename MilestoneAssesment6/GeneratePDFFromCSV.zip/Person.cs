﻿namespace GeneratePDFFromCSV
{
    class Person
    {
        public string Name { get; set; }
        public int Amount { get; set; }
    }
}
