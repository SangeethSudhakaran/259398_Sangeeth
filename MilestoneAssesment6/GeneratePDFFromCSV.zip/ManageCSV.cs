﻿using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;

namespace GeneratePDFFromCSV
{
    static class ManageCSV
    {
        //Function to read CSV file
        public static List<Person> ReadCsvFile(string filePath)
        {
            //List to add person
            var people = new List<Person>();

            Console.WriteLine("Reading data from CSV");
            using (var reader = new StreamReader(filePath))
            {
                // Skip header
                string headerLine = reader.ReadLine();

                //Adding CS data to the list
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    if (values.Length == 2)
                    {
                        var name = values[0].Trim();
                        if (int.TryParse(values[1].Trim(), out int amount))
                        {
                            people.Add(new Person { Name = name, Amount = amount });
                        }
                    }
                }
            }
            //Return list
            Console.WriteLine("Data successfully fetch from CSV");
            return people;
        }

        //Function to generate pdf
        public static void GeneratePdfReport(List<Person> people, string filePath)
        {
            //Initialization
            using (var writer = new PdfWriter(filePath))
            using (var pdf = new PdfDocument(writer))
            {
                var document = new Document(pdf);
                Console.WriteLine("PDF generation started");

                //Adding report header
                document.Add(new Paragraph("Summary Report").SetFontSize(20));
                Console.WriteLine("Added report header");

                //Adding table header
                var table = new Table(2);
                table.AddHeaderCell("Name");
                table.AddHeaderCell("Amount");
                Console.WriteLine("Added table headers");

                //Adding table data
                foreach (var person in people)
                {
                    table.AddCell(person.Name);
                    table.AddCell(person.Amount.ToString());
                }
                Console.WriteLine("Added table data");

                document.Add(table);
                document.Close();
                Console.WriteLine($"PDF generated successfully\nFile saved in : {Path.Combine(AppDomain.CurrentDomain.BaseDirectory, filePath)}");
            }
        }
    }
}
