﻿using System.Diagnostics;

namespace InvokePythonCode
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Define the numbers to sum
            int num1 = 5;
            int num2 = 10;

            //Create a new process
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "python"; //Specify python executable
            start.Arguments = $"sum_script.py {num1} {num2}"; //Pass arguments
            start.RedirectStandardOutput = true; //Redirect output
            start.UseShellExecute = false; //Don't use shell
            start.CreateNoWindow = true; //No window

            //Invoke python and read output
            using (Process process = Process.Start(start))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadLine(); //Read the output
                    Console.WriteLine($"The sum is: {result}"); //Print the result
                }
            }
        }
    }
}