﻿namespace PdfReportGenerator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Sample Inputs
            string title = "Monthly Sales Report";
            string text = "Total Sales: $10,000.00";

            //Report and image path
            string outputPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SalesReport.pdf");
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "finance.png");

            //Generate PDF
            CreateAndModifyPdfReport.CreatePDF(title, text, imagePath, outputPath);
            Console.WriteLine($"PDF report modified and saved : {outputPath}");
        }
    }
}