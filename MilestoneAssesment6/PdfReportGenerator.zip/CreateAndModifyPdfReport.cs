﻿using iText.IO.Image;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;

namespace PdfReportGenerator
{
    public static class CreateAndModifyPdfReport
    {
        public static void CreatePDF(string title, string text, string imagePath, string outputPath)
        {
            //Create a PdfWriter
            using (PdfWriter writer = new PdfWriter(outputPath))
            {
                //Create a PdfDocument
                using (PdfDocument pdf = new PdfDocument(writer))
                {
                    //Create a Document
                    Document document = new Document(pdf);
                    Console.WriteLine($"PDF report created at - {outputPath}");

                    //Add Title
                    Console.WriteLine($"PDF report started modifying..");
                    document.Add(new Paragraph(title).SetFontSize(24).SetBold().SetMarginBottom(20));
                    Console.WriteLine($"Added title");
                    
                    //Add Text
                    document.Add(new Paragraph(text).SetFontSize(16).SetMarginBottom(20));
                    Console.WriteLine($"Added text");

                    //Add Image
                    if (File.Exists(imagePath))
                    {
                        Image img = new Image(ImageDataFactory.Create(imagePath));
                        img.SetWidth(500); //Adjust width as needed
                        document.Add(img);
                        Console.WriteLine($"Added image");
                    }
                    else
                    {
                        document.Add(new Paragraph("Image not found: " + imagePath));
                    }

                    //Add Additional Text
                    document.Add(new Paragraph("**This is an auto generated pdf file, no sign is required**").SetFontSize(10).SetMarginBottom(1));
                    Console.WriteLine($"Added additional text");

                    //Close the document
                    document.Close();
                }
            }
        }
    }
}
