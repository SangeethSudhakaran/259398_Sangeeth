﻿namespace FoodDeliveryManagement
{
    public class Incident
    {
        public string short_description { get; set; }
    }
}
