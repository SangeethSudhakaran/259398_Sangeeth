﻿namespace FlightBookingSystem
{
    class InternationalFlight : Flight
    {
        public override decimal CalculateFare()
        {
            return BaseFare * 1.5m; // Increased fare for international
        }

        public override void DisplayDetails()
        {
            Console.WriteLine($"International Flight\t\t{FlightNumber} to {Destination}\t Fare: {CalculateFare()}");
        }
    }
}
